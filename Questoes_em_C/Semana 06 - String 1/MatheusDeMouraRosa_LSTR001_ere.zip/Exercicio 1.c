// 1 - Declare uma string com capacidade de armazenar um nome com 25 caracteres.
#include <stdio.h>
#include <string.h>

int main()
{
    char Nome[25];

    return (0);
}
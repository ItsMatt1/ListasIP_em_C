// 2.4 Coloca todos os caracteres de str em letra minusculas
#include <stdio.h>
#include <string.h>

int main()
{

    char Nome[25];

    gets(Nome);

    puts(strlwr(Nome));

    return (0);
}
#include <stdio.h>

main ()
{
	float pesoDosPeixes, excesso, multa;
		
	printf("Insira o peso dos peixes.\n");	
	scanf("%f", &pesoDosPeixes);
	
	excesso = ((pesoDosPeixes) - 50);
	
	multa = ((excesso) * 4.0);
	
	printf("O excesso de Kgs dos Peixes � = %f\n", excesso);
	printf("O valor da multa � = %f\n", multa);
	printf("O peso dos peixes � = %f\n", pesoDosPeixes);
	
}

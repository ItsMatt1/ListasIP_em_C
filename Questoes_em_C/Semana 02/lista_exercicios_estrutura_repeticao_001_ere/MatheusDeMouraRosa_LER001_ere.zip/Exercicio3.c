#include <stdio.h>

int main()
{
    for (int i = 100; i >= 0; i--)
    {
        printf("%d ", i);
    }

    return(0);
}